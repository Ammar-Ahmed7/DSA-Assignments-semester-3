package com.company.Algorithms;

public class Test {
    public static void main(String[] args) {
        String string1 = "COMSATS University Islamabad, Lahore Campus";
        String string4 = "   comsats   university         islamabad,     lahore campus  ";
        String string2 = "talat";
        String string3 = "Pakistan";

        System.out.println(Strings.isPalindrome("Taat"));
    }
}
